---
name: ⚙ Improvement
about: You have some improvement to make PHPUnit better?
labels: enhancement
---

<!--
- Please target the master branch of PHPUnit.
-->
