<?php

namespace PharIo\Version;

class InvalidPreReleaseSuffixException extends \Exception implements Exception {

}
