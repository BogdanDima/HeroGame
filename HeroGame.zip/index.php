<?php

require 'vendor/autoload.php';

require 'fight.php';
?>
